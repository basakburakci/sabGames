using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerator : MonoBehaviour
{
    [SerializeField] private Transform levelPart_1;
    public int levelLength = 72;
    public int i = 88;
    private GameObject playerObj = null;

    private void Start()
    {
        if (playerObj == null)
        {
            playerObj = GameObject.Find("Player");
        }
    }

    private void Update()
    {
        if (playerObj.transform.position.z >= i-levelLength)
        {
            SpawnLevelPart(new Vector3(26.7f, 22, i));
            i += levelLength;
        }

        //playerObj.Translate(Vector3, 0, 0, 1);
    }

    private void SpawnLevelPart(Vector3 spawnPosition)
    {
        Instantiate(levelPart_1, spawnPosition, Quaternion.identity);
    }
}
