using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int speed = 6;
    public int jumpspeed = 1;
    private Rigidbody rigid;
    public float Height;
    bool IsGrounded;
    Ray ray;
    MeshRenderer renda;
    void Start()
    {
        rigid = GetComponent<Rigidbody>();
        Height = renda.bounds.size.y;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            rigid.AddForce(Vector3.forward * speed);
        }
        if (Input.GetKey(KeyCode.S))
        {
            rigid.AddForce(Vector3.back * speed);
        }
        if (Input.GetKey(KeyCode.D))
        {
            rigid.AddForce(Vector3.right * speed);
        }
        if (Input.GetKey(KeyCode.A))
        {
            rigid.AddForce(Vector3.left * speed);
        }
        if (Input.GetKey(KeyCode.Space))
        {
            if(Physics.Raycast(transform.position, Vector3.down, Height))
            {
                Debug.Log("asd");
                Vector3 jump = new Vector3(0.0f, 2.0f, 0.0f);
                rigid.AddForce(jump * jumpspeed);
            }

        }

    }
 }


