using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 direction;
    private Vector3 newPosition;
    public float forwardSpeed;
    private int lane = 1;
    public float laneDistance = 4;
    public float JumpDistance;
    public float Gravity = -20;
    void Start()
    {
        controller = GetComponent<CharacterController>();

    }

    // Update is called once per frame
    void Update()
    {
        direction.z = forwardSpeed;

        if (controller.isGrounded)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Jump();
            }
        }
        else
        {
            direction.y += Gravity * Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.D) && lane!=2)
        {
            lane++;
        }
        if (Input.GetKeyDown(KeyCode.A) && lane!=0)
        {
            lane--;
        }
        newPosition = transform.position.z * transform.forward + transform.position.y * transform.up;
        if (lane == 0)
        {
            newPosition += Vector3.left * laneDistance;
        }
        else if (lane == 2)
        {
            newPosition += Vector3.right * laneDistance;
        }
        //transform.position = newPosition;
        
    }

    private void FixedUpdate()
    {
        controller.Move(direction * Time.fixedDeltaTime);
        transform.position = Vector3.Lerp(transform.position, newPosition, Time.deltaTime*3);
    }

    private void Jump()
    {
        direction.y = JumpDistance;
    }
}
